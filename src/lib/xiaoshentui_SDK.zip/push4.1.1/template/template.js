var app = getApp(); Page({ data: { }, onLoad: function () { } });
